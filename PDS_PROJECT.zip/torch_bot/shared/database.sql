CREATE SCHEMA `Doc_Bot`;

CREATE TABLE `Doc_Bot`.`patient_details` (
  `id` INT NOT NULL AUTO_INCREMENT,
  `name` VARCHAR(45) NULL,
  `phone` INT NULL,
  PRIMARY KEY (`id`));

INSERT INTO `Doc_Bot`.`patient_details` (`id`, `name`, `phone`) VALUES ('1', 'Test Patient 1', '1234567891');
INSERT INTO `Doc_Bot`.`patient_details` (`name`, `phone`) VALUES ('Test Patient 2', '1234567819');

CREATE TABLE `Doc_Bot`.`patient_appointment` (
  `id` INT NOT NULL,
  `patient_id` INT NULL,
  `date` VARCHAR(45) NULL,
  `doctor` VARCHAR(45) NULL,
  PRIMARY KEY (`id`),
  INDEX `id_idx` (`patient_id` ASC) VISIBLE,
  CONSTRAINT `id`
    FOREIGN KEY (`patient_id`)
    REFERENCES `Doc_Bot`.`patient_details` (`id`)
    ON DELETE CASCADE
    ON UPDATE NO ACTION);

