import nltk
# from nltk.stem.porter import PorterStemmer
from nltk.stem import WordNetLemmatizer
import numpy as np

# stemmer = PorterStemmer()
lemmatizer = WordNetLemmatizer()

def tokenize(sentense):
    """
    return the tekonized array
    sentense: str
    """
    return nltk.word_tokenize(sentense)


def stem(word):
    """
    return the root word
    word: str
    """
    # return stemmer.stem(word=word.lower())
    return lemmatizer.lemmatize(word=word.lower())


def bag_of_words(tokenized_sentence, all_words):
    """
    Bag of words
    returns [0, 1, 0]
    """
    tok = [stem(each) for each in tokenized_sentence]
    bag = np.zeros(len(all_words), dtype=np.float32)
    for idx, w in enumerate(all_words):
        if w in tok:
            bag[idx] = 1.0
    return bag

# test
if __name__ == "__main__":
    string = "How are you doing?"
    tok = tokenize(string)
    print(tok)
    