//
//  Message.swift
//  doc_chat
//
//  
//

import Foundation

enum Type: String {
    case Direct = "Direct"
    case ID = "Id"
    case FORM = "Form"
}

struct Message: Codable, Identifiable {
    var id = UUID()
    let message: String?
    let type: String
    let via: String
}

