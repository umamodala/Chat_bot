//
//  Constant.swift
//  doc_chat
//
//  
//

import Foundation

struct Constant {
    static let BASE_URL = "http://127.0.0.1:8000/"
    static let sendMessage = "\(BASE_URL)send"
    static let bookAppointment = ""
    static let retrivePatientInfo = ""
    static let drInfo = ""
}

