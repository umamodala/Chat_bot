//
//  doc_chatApp.swift
//  doc_chat
//
//
//

import SwiftUI

@main
struct doc_chatApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
