//
//  BookingAppointmentView.swift
//  doc_chat
//
//  
//

import SwiftUI

struct BookingAppointmentView: View {
    @State var name = ""
    @State var drName = ""
    var body: some View {
        VStack(alignment: .leading){
            TextField("Patient Name", text: $name)
                .padding()
                .textFieldStyle(.roundedBorder)
            Button("Submit"){
                
            }
            .buttonStyle(.borderedProminent)
            .padding(.leading)
            .padding(.bottom)
        }
        .frame(maxWidth: .infinity)
    }
}

#Preview(traits: .sizeThatFitsLayout) {
    BookingAppointmentView()
}
